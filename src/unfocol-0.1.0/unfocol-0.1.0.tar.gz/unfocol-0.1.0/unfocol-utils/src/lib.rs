pub mod color;

#[cfg(test)]
mod tests {
    use super::*;
}
